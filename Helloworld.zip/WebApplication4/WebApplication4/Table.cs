namespace WebApplication4
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("Table")]
    public partial class Table
    {
        public int Id { get; set; }

        [StringLength(20)]
        public string P1 { get; set; }
        public string P2 { get; set; }
        public int P3 { get; set; }
    }
}
